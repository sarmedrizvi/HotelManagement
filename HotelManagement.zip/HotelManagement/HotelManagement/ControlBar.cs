﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HotelManagement
{
    public partial class ControlBar : UserControl
    {
        public ControlBar()
        {
            InitializeComponent();
        }
        Form f;
        public static bool ismaximize = true;
        public Form GetForm { get { return f; } set { f = value; } }
        public string Title { get { return label1.Text; } set { label1.Text = value; } }
        public Image ICON { get { return pictureBox4.Image; } set { pictureBox4.Image = value; } }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            if (ismaximize)
            {
                f.MaximumSize = Screen.PrimaryScreen.WorkingArea.Size;
                f.WindowState = FormWindowState.Maximized;
                ismaximize = false;
           
            }
            else
            {
                f.WindowState = FormWindowState.Normal;
                ismaximize = true;
            }
        }

        private void ControlBar_Load(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            string message = "Are you Sure?";
            string caption = "Exit";
            MessageBoxButtons buttons = MessageBoxButtons.YesNo;
            DialogResult result;
            result = MessageBox.Show(message, caption, buttons, MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
            {
                Application.Exit();

            }
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            f.WindowState = FormWindowState.Minimized;
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}
