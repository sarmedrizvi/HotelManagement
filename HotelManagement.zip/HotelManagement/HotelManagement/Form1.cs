﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HotelManagement
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void controlBar1_Load(object sender, EventArgs e)
        {
            timer1.Start();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void sideBar1_ClickDashBoard(object sender, EventArgs e)
        {
            dashBoard1.BringToFront();
        }

        private void sideBar1_ClickEmployees(object sender, EventArgs e)
        {
            employees1.BringToFront();
        }

        private void timer1_Tick_1(object sender, EventArgs e)
        {
            controlBar1.Title = DateTime.Now.ToString();
        }
    }
}
