﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace HotelManagement
{
    public partial class Employees : UserControl
    {
        public static string connectionString = @"Data Source=DESKTOP-5HNPRO6;Initial Catalog=HotelManagement;Integrated Security=True";
        public static SqlConnection Sql = new SqlConnection(connectionString);
        public Employees()
        {
            InitializeComponent();
            filter1.ViewByForeColor = Color.White;
        }

        private void filter1_GridViewClick(object sender, EventArgs e)
        {
            viewsPanel.Controls.Clear();
            if (Sql.State == ConnectionState.Closed)
            {
                Sql.Open();
            }
            string com = "select EmployeeId,EmployeeName,EmployeeGender,EmployeePhoneNumber,EmployeeSalary from Employees";
            SqlCommand sql = new SqlCommand(com, Sql);
            SqlDataAdapter dataAdapter = new SqlDataAdapter(); DataTable dataTable = new DataTable();
            dataAdapter.SelectCommand = sql;
            dataAdapter.Fill(dataTable);
            DataGridView dataGridView1 = new DataGridView();
            viewsPanel.Controls.Add(dataGridView1);
            dataGridView1.Dock = DockStyle.Fill;
            dataGridView1.AllowUserToAddRows = false;
            dataGridView1.AllowUserToDeleteRows = false;
            dataGridView1.AllowUserToOrderColumns = false;
            dataGridView1.AllowUserToResizeRows = false;
            dataGridView1.AllowUserToResizeColumns = false;
            dataGridView1.AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill;
            dataGridView1.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.AllCells;
            dataGridView1.BackgroundColor = Color.White;
            dataGridView1.ColumnHeadersHeightSizeMode = DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridView1.RowHeadersWidthSizeMode = DataGridViewRowHeadersWidthSizeMode.DisableResizing;
            dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            dataGridView1.ShowEditingIcon = false;
            dataGridView1.RowHeadersBorderStyle = DataGridViewHeaderBorderStyle.Raised;
            dataGridView1.MultiSelect = false;
            dataGridView1.ReadOnly = true;
            dataGridView1.ClipboardCopyMode = DataGridViewClipboardCopyMode.EnableWithAutoHeaderText;
            dataGridView1.EditMode = DataGridViewEditMode.EditOnKeystrokeOrF2;
            dataGridView1.DataSource = dataTable;
            sql.ExecuteNonQuery();
        }
        ListViewPanels list;
        bool a, b, c, d, ee, f, g = true;

        private void filter1_Load_2(object sender, EventArgs e)
        {

        }

        private void filter1_Load_1(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void filter1_ListViewClick(object sender, EventArgs e)
        {
            viewsPanel.Controls.Clear();
            if (Sql.State == ConnectionState.Closed)
            {
                Sql.Open();
            }
            string com = "select * from Employees";
            SqlCommand sql = new SqlCommand(com, Sql);
            SqlDataAdapter dataAdapter = new SqlDataAdapter(); DataTable dataTable = new DataTable();
            sql.ExecuteNonQuery();
            dataAdapter.SelectCommand = sql;
            dataAdapter.Fill(dataTable);
            if(dataTable.Rows.Count!=0)
            {
                for (int i = 0; i < dataTable.Rows.Count; i++)
                {
                    if(i%7==0)
                    {
                        list = new ListViewPanels();
                        list.Dock = DockStyle.Top;
                        viewsPanel.Controls.Add(list);

                        a = true;b = false;c = false;d = false;ee = false;f = false;g = false;
                    }
                    if (a)
                    {
                        list.listView1.label1.Text = dataTable.Rows[i][0].ToString();
                        list.listView1.Visible = true;
                        list.listView1.label2.Text = dataTable.Rows[i][1].ToString();
                        list.listView1.label3.Text = dataTable.Rows[i][3].ToString();
                        a = false; b = true; c = false; d = false; ee = false; f = false; g = false;
                        continue;
                    }
                    else if(b)
                    {
                        list.listView2.label1.Text = dataTable.Rows[i][0].ToString();
                        list.listView2.Visible = true;
                        list.listView2.label2.Text = dataTable.Rows[i][1].ToString();
                        list.listView2.label3.Text = dataTable.Rows[i][3].ToString();
                        a = false; b = false; c = true; d = false; ee = false; f = false; g = false;
                        continue;
                    }
                    else if(c)
                    {
                        list.listView3.label1.Text = dataTable.Rows[i][0].ToString();
                        list.listView3.Visible = true;
                        list.listView3.label2.Text = dataTable.Rows[i][1].ToString();
                        list.listView3.label3.Text = dataTable.Rows[i][3].ToString();
                        a = false; b = false; c = false; d = true; ee = false; f = false; g = false;
                        continue;
                    }
                    else if (d)
                    {
                        list.listView4.label1.Text = dataTable.Rows[i][0].ToString();
                        list.listView4.Visible = true;
                        list.listView4.label2.Text = dataTable.Rows[i][1].ToString();
                        list.listView4.label3.Text = dataTable.Rows[i][3].ToString();
                        a = false; b = false; c = false; d = false; ee = true; f = false; g = false;
                        continue;
                    }
                    else if (ee)
                    {
                        list.listView5.label1.Text = dataTable.Rows[i][0].ToString();
                        list.listView5.Visible = true;
                        list.listView5.label2.Text = dataTable.Rows[i][1].ToString();
                        list.listView5.label3.Text = dataTable.Rows[i][3].ToString();
                        a = false; b =false; c = false; d = false; ee = false; f = true; g = false;
                        continue;
                    }
                    else if (f)
                    {
                        list.listView6.label1.Text = dataTable.Rows[i][0].ToString();
                        list.listView6.Visible = true;
                        list.listView6.label2.Text = dataTable.Rows[i][1].ToString();
                        list.listView6.label3.Text = dataTable.Rows[i][3].ToString();
                        a = false; b = false; c = false; d = false; ee = false; f = false; g = true;
                        continue;
                    }
                    else if (g)
                    {
                        list.listView7.label1.Text = dataTable.Rows[i][0].ToString();
                        list.listView7.Visible = true;
                        list.listView7.label2.Text = dataTable.Rows[i][1].ToString();
                        list.listView7.label3.Text = dataTable.Rows[i][3].ToString();

                    }
                   
                }
            }


        }

        private void filter1_Load(object sender, EventArgs e)
        {

        }
    }
}
