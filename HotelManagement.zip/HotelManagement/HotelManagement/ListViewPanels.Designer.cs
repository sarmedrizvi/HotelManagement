﻿namespace HotelManagement
{
    partial class ListViewPanels
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.listView7 = new HotelManagement.ListView();
            this.listView6 = new HotelManagement.ListView();
            this.listView5 = new HotelManagement.ListView();
            this.listView4 = new HotelManagement.ListView();
            this.listView3 = new HotelManagement.ListView();
            this.listView2 = new HotelManagement.ListView();
            this.listView1 = new HotelManagement.ListView();
            this.SuspendLayout();
            // 
            // listView7
            // 
            this.listView7.BackColor = System.Drawing.Color.Transparent;
            this.listView7.Dock = System.Windows.Forms.DockStyle.Left;
            this.listView7.Location = new System.Drawing.Point(852, 0);
            this.listView7.Name = "listView7";
            this.listView7.Size = new System.Drawing.Size(142, 211);
            this.listView7.TabIndex = 6;
            this.listView7.Visible = false;
            // 
            // listView6
            // 
            this.listView6.BackColor = System.Drawing.Color.Transparent;
            this.listView6.Dock = System.Windows.Forms.DockStyle.Left;
            this.listView6.Location = new System.Drawing.Point(710, 0);
            this.listView6.Name = "listView6";
            this.listView6.Size = new System.Drawing.Size(142, 211);
            this.listView6.TabIndex = 5;
            this.listView6.Visible = false;
            // 
            // listView5
            // 
            this.listView5.BackColor = System.Drawing.Color.Transparent;
            this.listView5.Dock = System.Windows.Forms.DockStyle.Left;
            this.listView5.Location = new System.Drawing.Point(568, 0);
            this.listView5.Name = "listView5";
            this.listView5.Size = new System.Drawing.Size(142, 211);
            this.listView5.TabIndex = 4;
            this.listView5.Visible = false;
            // 
            // listView4
            // 
            this.listView4.BackColor = System.Drawing.Color.Transparent;
            this.listView4.Dock = System.Windows.Forms.DockStyle.Left;
            this.listView4.Location = new System.Drawing.Point(426, 0);
            this.listView4.Name = "listView4";
            this.listView4.Size = new System.Drawing.Size(142, 211);
            this.listView4.TabIndex = 3;
            this.listView4.Visible = false;
            // 
            // listView3
            // 
            this.listView3.BackColor = System.Drawing.Color.Transparent;
            this.listView3.Dock = System.Windows.Forms.DockStyle.Left;
            this.listView3.Location = new System.Drawing.Point(284, 0);
            this.listView3.Name = "listView3";
            this.listView3.Size = new System.Drawing.Size(142, 211);
            this.listView3.TabIndex = 2;
            this.listView3.Visible = false;
            // 
            // listView2
            // 
            this.listView2.BackColor = System.Drawing.Color.Transparent;
            this.listView2.Dock = System.Windows.Forms.DockStyle.Left;
            this.listView2.Location = new System.Drawing.Point(142, 0);
            this.listView2.Name = "listView2";
            this.listView2.Size = new System.Drawing.Size(142, 211);
            this.listView2.TabIndex = 1;
            this.listView2.Visible = false;
            // 
            // listView1
            // 
            this.listView1.BackColor = System.Drawing.Color.Transparent;
            this.listView1.Dock = System.Windows.Forms.DockStyle.Left;
            this.listView1.Location = new System.Drawing.Point(0, 0);
            this.listView1.Name = "listView1";
            this.listView1.Size = new System.Drawing.Size(142, 211);
            this.listView1.TabIndex = 0;
            this.listView1.Visible = false;
            // 
            // ListViewPanels
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Transparent;
            this.Controls.Add(this.listView7);
            this.Controls.Add(this.listView6);
            this.Controls.Add(this.listView5);
            this.Controls.Add(this.listView4);
            this.Controls.Add(this.listView3);
            this.Controls.Add(this.listView2);
            this.Controls.Add(this.listView1);
            this.DoubleBuffered = true;
            this.Name = "ListViewPanels";
            this.Size = new System.Drawing.Size(994, 211);
            this.ResumeLayout(false);

        }

        #endregion

        public ListView listView1;
        public ListView listView2;
        public ListView listView3;
        public ListView listView4;
        public ListView listView5;
        public ListView listView6;
        public ListView listView7;
    }
}
