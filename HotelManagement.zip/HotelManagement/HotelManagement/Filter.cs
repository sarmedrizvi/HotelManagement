﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HotelManagement
{
   
    public partial class Filter : UserControl
    {
        public event Click GridViewClick;
        public event Click ListViewClick;
        public Filter()
        {
            InitializeComponent();
        }
        public Color ViewByForeColor { get { return label2.ForeColor; } set { label2.ForeColor = value; } }

        private void Filter_Load(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {
            button5.BackColor = Color.Gray;
            button4.BackColor = Color.White;
            if(GridViewClick!=null)
            {
                GridViewClick(sender, e);
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            button4.BackColor = Color.Gray;
            button5.BackColor = Color.White;
            if(ListViewClick!=null)
            {
                ListViewClick(sender, e);
            }
        }

        private void textBox1_TextChanged_1(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }
    }
}
