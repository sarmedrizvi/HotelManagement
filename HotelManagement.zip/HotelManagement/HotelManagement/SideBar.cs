﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HotelManagement
{
    public delegate void Click(object sender, EventArgs e);
    public partial class SideBar : UserControl
    {
        public event Click ClickRoom;
        public event Click ClickBooking;
        public event Click ClickEmployees;
        public event Click ClickClients;
        public event Click ClickTransaction;
        public event Click ClickReports;
        public event Click ClickProfile;
        public event Click ClickDashBoard;


        public SideBar()
        {
            InitializeComponent();
        }

        private void label3_Click(object sender, EventArgs e)
        {
            if (ClickEmployees != null)
                ClickEmployees(sender, e);
        }

        private void SideBar_Load(object sender, EventArgs e)
        {

        }

        private void label1_MouseHover(object sender, EventArgs e)
        {
            label1.Font = new Font("Sakkal Majalla", 17F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
        }

        private void label1_MouseLeave(object sender, EventArgs e)
        {
            label1.Font = new Font("Sakkal Majalla", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
        }

        private void label2_MouseHover(object sender, EventArgs e)
        {
            label2.Font = new Font("Sakkal Majalla", 17F, FontStyle.Bold, GraphicsUnit.Point);
        }

        private void label2_MouseLeave(object sender, EventArgs e)
        {
            label2.Font = new Font("Sakkal Majalla", 14.25F,FontStyle.Bold,GraphicsUnit.Point);
        }

        private void label3_MouseHover(object sender, EventArgs e)
        {
            label3.Font = new Font("Sakkal Majalla", 17F, FontStyle.Bold, GraphicsUnit.Point);
        }

        private void label3_MouseLeave(object sender, EventArgs e)
        {
            label3.Font = new Font("Sakkal Majalla", 14.25F, FontStyle.Bold, GraphicsUnit.Point);
        }

        private void label8_MouseHover(object sender, EventArgs e)
        {
            label8.Font = new Font("Sakkal Majalla", 17F, FontStyle.Bold, GraphicsUnit.Point);
        }

        private void label8_MouseLeave(object sender, EventArgs e)
        {
            label8.Font = new Font("Sakkal Majalla", 14.25F, FontStyle.Bold, GraphicsUnit.Point);
        }

        private void label4_MouseHover(object sender, EventArgs e)
        {
            label4.Font = new Font("Sakkal Majalla", 17F, FontStyle.Bold, GraphicsUnit.Point);
        }

        private void label4_MouseLeave(object sender, EventArgs e)
        {
            label4.Font = new Font("Sakkal Majalla", 14.25F, FontStyle.Bold, GraphicsUnit.Point);
        }

        private void label6_MouseHover(object sender, EventArgs e)
        {
            label6.Font = new Font("Sakkal Majalla", 17F, FontStyle.Bold, GraphicsUnit.Point);
        }

        private void label6_MouseLeave(object sender, EventArgs e)
        {
            label6.Font = new Font("Sakkal Majalla", 14.25F, FontStyle.Bold, GraphicsUnit.Point);
        }

        private void label7_MouseHover(object sender, EventArgs e)
        {
            label7.Font = new Font("Sakkal Majalla", 17F, FontStyle.Bold, GraphicsUnit.Point);
        }

        private void label7_MouseLeave(object sender, EventArgs e)
        {
            label7.Font = new Font("Sakkal Majalla", 14.25F, FontStyle.Bold, GraphicsUnit.Point);
        }

        private void label1_Click(object sender, EventArgs e)
        {
            if (ClickRoom != null)
                ClickRoom(sender, e);
        }

        private void label2_Click(object sender, EventArgs e)
        {
            if (ClickBooking != null)
                ClickBooking(sender, e);
        }

        private void label8_Click(object sender, EventArgs e)
        {
            if (ClickClients != null)
                ClickClients(sender, e);
        }

        private void label4_Click(object sender, EventArgs e)
        {
            if (ClickTransaction != null)
                ClickTransaction(sender, e);
        }

        private void label6_Click(object sender, EventArgs e)
        {
            if (ClickReports != null)
                ClickReports(sender, e);
        }

        private void label7_Click(object sender, EventArgs e)
        {
            if (ClickProfile != null)
                ClickProfile(sender, e);
        }

        private void home_Click(object sender, EventArgs e)
        {
            if (ClickDashBoard != null)
                ClickDashBoard(sender, e);
        }

        private void home_MouseHover(object sender, EventArgs e)
        {
            home.Font = new Font("Sakkal Majalla", 17F, FontStyle.Bold, GraphicsUnit.Point);
        }

        private void home_MouseLeave(object sender, EventArgs e)
        {
            home.Font = new Font("Sakkal Majalla", 14.25F, FontStyle.Bold, GraphicsUnit.Point);
        }
    }
}
