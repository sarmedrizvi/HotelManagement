﻿namespace HotelManagement
{
    partial class Employees
    {
        /// <summary> 
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary> 
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Component Designer generated code

        /// <summary> 
        /// Required method for Designer support - do not modify 
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.panel1 = new System.Windows.Forms.Panel();
            this.viewsPanel = new System.Windows.Forms.Panel();
            this.filter1 = new HotelManagement.Filter();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.Brown;
            this.label1.Dock = System.Windows.Forms.DockStyle.Top;
            this.label1.Font = new System.Drawing.Font("Sakkal Majalla", 48F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.Location = new System.Drawing.Point(0, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(1078, 80);
            this.label1.TabIndex = 0;
            this.label1.Text = "Employees";
            this.label1.Click += new System.EventHandler(this.label1_Click);
            // 
            // panel1
            // 
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(0, 80);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1078, 27);
            this.panel1.TabIndex = 1;
            // 
            // viewsPanel
            // 
            this.viewsPanel.AutoScroll = true;
            this.viewsPanel.BackColor = System.Drawing.Color.Transparent;
            this.viewsPanel.Dock = System.Windows.Forms.DockStyle.Fill;
            this.viewsPanel.Location = new System.Drawing.Point(0, 139);
            this.viewsPanel.Name = "viewsPanel";
            this.viewsPanel.Size = new System.Drawing.Size(1078, 285);
            this.viewsPanel.TabIndex = 5;
            // 
            // filter1
            // 
            this.filter1.BackColor = System.Drawing.Color.Transparent;
            this.filter1.Dock = System.Windows.Forms.DockStyle.Top;
            this.filter1.Location = new System.Drawing.Point(0, 107);
            this.filter1.Name = "filter1";
            this.filter1.Size = new System.Drawing.Size(1078, 32);
            this.filter1.TabIndex = 4;
            this.filter1.ViewByForeColor = System.Drawing.SystemColors.ControlText;
            this.filter1.GridViewClick += new HotelManagement.Click(this.filter1_GridViewClick);
            this.filter1.ListViewClick += new HotelManagement.Click(this.filter1_ListViewClick);
            this.filter1.Load += new System.EventHandler(this.filter1_Load_2);
            // 
            // Employees
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Transparent;
            this.Controls.Add(this.viewsPanel);
            this.Controls.Add(this.filter1);
            this.Controls.Add(this.panel1);
            this.Controls.Add(this.label1);
            this.DoubleBuffered = true;
            this.Name = "Employees";
            this.Size = new System.Drawing.Size(1078, 424);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Panel viewsPanel;
        private Filter filter1;
    }
}
