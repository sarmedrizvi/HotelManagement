﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EmailComposer
{
    public delegate void Load1(object sender, EventArgs e);
    public delegate void Exit1(object sender, EventArgs e);
    public partial class ControlBar : UserControl
    {
        public event Load1 load;
        public event Exit1 exit;
        bool ismove = false;
        Point LastLocation;
        public static bool ismaximize, how;
        Form f;


        public ControlBar()
        {

            InitializeComponent();
        }
        public bool Isclosebutton { get { return label1.Visible; } set { label1.Visible = value; } }
        public bool Ismaximumsize { get { return label3.Visible; } set { label3.Visible = value; } }
        public bool Isminimizebox { get { return label2.Visible; } set { label2.Visible = value; } }
        public string Title { get { return label4.Text; } set { label4.Text = value; } }
        public Image Icon { get { return pictureBox1.Image; } set { pictureBox1.Image = value; } }

        private void ControlBar_Load(object sender, EventArgs e)
        {
            ismaximize = true;
            if (load != null)
            {
                load(sender, e);
            }
            else
            {
                if (how == true)
                {
                    f.MaximumSize = Screen.PrimaryScreen.WorkingArea.Size;
                    f.WindowState = FormWindowState.Maximized;
                    ismaximize = false;
                }
                else
                {
                    f.WindowState = FormWindowState.Normal;
                    ismaximize = true;
                }
            }

        }

        public Form MainForm { get { return f; } set { f = value; } }

        ToolTip tt = new ToolTip();

        private void label1_MouseHover(object sender, EventArgs e)
        {
            label1.BackColor = Color.White;
            tt.SetToolTip(this.label1, "Close");
        }

        private void label1_MouseLeave(object sender, EventArgs e)
        {
            Color a;
            a = BackColor;
            label1.BackColor = a;
        }

        private void label3_MouseHover(object sender, EventArgs e)
        {
            label3.BackColor = Color.White;
            if (ismaximize == false)
                tt.SetToolTip(this.label3, "Restore Down");
            else
                tt.SetToolTip(this.label3, "maximum");

        }
        private void label1_Click(object sender, EventArgs e)
        {


            if (exit != null)
            {
                exit(sender, e);
              
            }
            else
            {
                string message = "Are you Sure?";
                string caption = "Exit";
                MessageBoxButtons buttons = MessageBoxButtons.YesNo;
                DialogResult result;
                result = MessageBox.Show(message, caption, buttons,MessageBoxIcon.Question);

                if (result == DialogResult.Yes)
                {
                    Application.Exit();

                }
            }

           
        }


        private void label3_Click(object sender, EventArgs e)
        {
            if (ismaximize)
            {
                f.MaximumSize = Screen.PrimaryScreen.WorkingArea.Size;
                f.WindowState = FormWindowState.Maximized;
                ismaximize = false;
                how = true;

            }
            else
            {
                f.WindowState = FormWindowState.Normal;
                ismaximize = true;
                how = false;
            }
        }

        private void label3_MouseLeave(object sender, EventArgs e)
        {
            Color a;
            a = BackColor;
            label3.BackColor = a;
        }

        private void label2_MouseHover(object sender, EventArgs e)
        {
            label2.BackColor = Color.White;

            tt.SetToolTip(this.label2, "Minimize");
        }

        private void label2_MouseLeave(object sender, EventArgs e)
        {
            Color a;
            a = BackColor;
            label2.BackColor = a;
        }

        private void label4_MouseHover(object sender, EventArgs e)
        {
            this.label4.Font = new System.Drawing.Font("Cooper Black", 20F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));

        }

        private void label4_MouseLeave(object sender, EventArgs e)
        {
            this.label4.Font = new System.Drawing.Font("Cooper Black", 18F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));

        }

        private void pictureBox1_MouseHover(object sender, EventArgs e)
        {



            pictureBox1.Size = new Size(140, 70);

        }

        private void pictureBox1_MouseLeave(object sender, EventArgs e)
        {
            pictureBox1.Size = new Size(145, 89);
        }

        private void label4_MouseDown(object sender, MouseEventArgs e)
        {
            ismove = true;
            LastLocation = e.Location;

        }


        private void label4_MouseUp(object sender, MouseEventArgs e)
        {
            ismove = false;
        }

        private void label4_MouseMove(object sender, MouseEventArgs e)
        {
            if (ismove)
            {
                f.Location = new Point(
                 (f.Location.X - LastLocation.X) + e.X, (f.Location.Y - LastLocation.Y) + e.Y);

                f.Update();
            }
        }

        private void pictureBox1_MouseDown(object sender, MouseEventArgs e)
        {
            ismove = true;
            LastLocation = e.Location;
        }

        private void pictureBox1_MouseMove(object sender, MouseEventArgs e)
        {
            if (ismove)
            {
                f.Location = new Point(
                 (f.Location.X - LastLocation.X) + e.X, (f.Location.Y - LastLocation.Y) + e.Y);

                f.Update();
            }

        }

        private void pictureBox1_MouseUp(object sender, MouseEventArgs e)
        {
            ismove = false;
        }

        private void timer1_Tick(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {
            f.WindowState = FormWindowState.Minimized;
        }
    }
}