﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace HotelManagement
{
    public partial class ListView : UserControl
    {
        public ListView()
        {
            InitializeComponent();
        }

        private void pictureBox1_MouseHover(object sender, EventArgs e)
        {
            pictureBox2.Visible = true;
            pictureBox1.BackColor = Color.Silver;
          
        }

        private void pictureBox1_MouseLeave(object sender, EventArgs e)
        {
            pictureBox2.Visible = false;
            pictureBox1.BackColor = Color.Transparent;
        }
        private void pictureBox2_Click(object sender, EventArgs e)
        {
            Visible = false;
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            string message = "Do you want to delete?";
            string caption = "Delete";
            MessageBoxButtons buttons = MessageBoxButtons.YesNo;
            DialogResult result;
            result = MessageBox.Show(message, caption, buttons, MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
            {
                Visible = false;
            }

        }
    }
}
