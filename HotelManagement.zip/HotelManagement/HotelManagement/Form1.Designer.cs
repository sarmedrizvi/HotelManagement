﻿namespace HotelManagement
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.dashBoard1 = new HotelManagement.DashBoard();
            this.sideBar1 = new HotelManagement.SideBar();
            this.controlBar1 = new HotelManagement.ControlBar();
            this.employees1 = new HotelManagement.Employees();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.SuspendLayout();
            // 
            // dashBoard1
            // 
            this.dashBoard1.BackColor = System.Drawing.Color.Transparent;
            this.dashBoard1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.dashBoard1.Location = new System.Drawing.Point(0, 183);
            this.dashBoard1.Name = "dashBoard1";
            this.dashBoard1.Size = new System.Drawing.Size(1078, 377);
            this.dashBoard1.TabIndex = 2;
            // 
            // sideBar1
            // 
            this.sideBar1.BackColor = System.Drawing.Color.Transparent;
            this.sideBar1.Dock = System.Windows.Forms.DockStyle.Top;
            this.sideBar1.Location = new System.Drawing.Point(0, 46);
            this.sideBar1.Name = "sideBar1";
            this.sideBar1.Size = new System.Drawing.Size(1078, 137);
            this.sideBar1.TabIndex = 1;
            this.sideBar1.ClickEmployees += new HotelManagement.Click(this.sideBar1_ClickEmployees);
            this.sideBar1.ClickDashBoard += new HotelManagement.Click(this.sideBar1_ClickDashBoard);
            // 
            // controlBar1
            // 
            this.controlBar1.BackColor = System.Drawing.Color.Transparent;
            this.controlBar1.Dock = System.Windows.Forms.DockStyle.Top;
            this.controlBar1.GetForm = this;
            this.controlBar1.ICON = global::HotelManagement.Properties.Resources.ICON1;
            this.controlBar1.Location = new System.Drawing.Point(0, 0);
            this.controlBar1.Name = "controlBar1";
            this.controlBar1.Size = new System.Drawing.Size(1078, 46);
            this.controlBar1.TabIndex = 0;
            this.controlBar1.Title = "";
            this.controlBar1.Load += new System.EventHandler(this.controlBar1_Load);
            // 
            // employees1
            // 
            this.employees1.BackColor = System.Drawing.Color.Transparent;
            this.employees1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.employees1.Location = new System.Drawing.Point(0, 0);
            this.employees1.Name = "employees1";
            this.employees1.Size = new System.Drawing.Size(1078, 560);
            this.employees1.TabIndex = 3;
            // 
            // timer1
            // 
            this.timer1.Enabled = true;
            this.timer1.Interval = 1000;
            this.timer1.Tick += new System.EventHandler(this.timer1_Tick_1);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::HotelManagement.Properties.Resources.BAckGround1;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1078, 560);
            this.ControlBox = false;
            this.Controls.Add(this.dashBoard1);
            this.Controls.Add(this.sideBar1);
            this.Controls.Add(this.controlBar1);
            this.Controls.Add(this.employees1);
            this.DoubleBuffered = true;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private ControlBar controlBar1;
        private SideBar sideBar1;
        private DashBoard dashBoard1;
        private Employees employees1;
        private System.Windows.Forms.Timer timer1;
    }
}

